import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("001", "Alice", "Jones", "1234567890", "111 Pine Rd");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact));
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("002", "Bob", "Mills", "0987654321", "222 Oak St");
        service.addContact(contact);
        service.deleteContact("002");
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("002"));
    }

    @Test
    public void testUpdateFields() {
        Contact contact = new Contact("003", "Charlie", "Brown", "1112223333", "333 Birch Ln");
        service.addContact(contact);

        service.updateFirstName("003", "Chuck");
        service.updateLastName("003", "Black");
        service.updatePhone("003", "4445556666");
        service.updateAddress("003", "999 New Address");

        assertEquals("Chuck", contact.getFirstName());
        assertEquals("Black", contact.getLastName());
        assertEquals("4445556666", contact.getPhone());
        assertEquals("999 New Address", contact.getAddress());
    }

    @Test
    public void testUpdateNonexistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updatePhone("999", "1231231234");
        });
    }
}
