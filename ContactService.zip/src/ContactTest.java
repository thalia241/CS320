import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {
	@Test
    public void testValidContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main Street");
        assertEquals("12345", contact.getContactID());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    public void testInvalidContactID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "12345", "123 Main St");
        });
    }

    @Test
    public void testUpdateFields() {
        Contact contact = new Contact("1", "Jane", "Smith", "1112223333", "456 Elm St");
        contact.setFirstName("Anna");
        contact.setLastName("Lee");
        contact.setPhone("9998887777");
        contact.setAddress("789 Oak Ave");

        assertEquals("Anna", contact.getFirstName());
        assertEquals("Lee", contact.getLastName());
        assertEquals("9998887777", contact.getPhone());
        assertEquals("789 Oak Ave", contact.getAddress());
    }
}
